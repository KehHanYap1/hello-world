package testunogame;

import java.util.ArrayList;
import java.util.Scanner;
import unogame.Game;

public class Test {

public static void main(String args[])
    {
        int totalCardsInDeck = 0;
        int numberOfPlayers = 0;
        int noOfCardsPerPlayer = 0;
 
        Scanner in = new Scanner(System.in);
        
        try 
        {
            System.out.println("Enter Total No. of Cards in Deck:");
            totalCardsInDeck = in.nextInt();
           
            System.out.println("\nEnter Total No. of Players:");
            numberOfPlayers = in.nextInt();
            
            ArrayList<String> playerIdList = new ArrayList<String> (numberOfPlayers);
            ArrayList<String> playerNameList = new ArrayList<String> (numberOfPlayers);
            
            System.out.println("\nEnter  No. of Cards Per Player:");
            noOfCardsPerPlayer = in.nextInt();
            
            for (int i=1;i<=numberOfPlayers;i++)
            {
                System.out.println("\nEnter Player " + i + " ID: ");
                playerIdList.add(in.next());

                System.out.println("\nEnter Player " + i + " Name: ");
                playerNameList.add(in.next());
            }
            
            
            new Game(1, totalCardsInDeck, numberOfPlayers, noOfCardsPerPlayer);
            
        }
        catch (Exception e)
        {
            System.out.print("Encountered Error:" +e.toString() +". Please re-run program.");
            System.exit(0);            
        }
    }    
}
