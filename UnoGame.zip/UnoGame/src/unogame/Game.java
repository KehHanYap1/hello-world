package unogame;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Date;

public class Game {
    
    private long gameId;
    private int numberOfPlayers;
    private int noOfCardsPerPlayer;
    private ArrayList<Player> players;
    private int totalCardsInDeck;
    private Deck newDeck;
    private ArrayList<Card> discardPile;
    private int gameStatus = 0; //0=waiting, 1=started, 2=ended
    
    private static ArrayList<String> playerIdList;
    private static ArrayList<String> playerNameList;

    public Game(int gameStatus, int totalCardsInDeck, int numberOfPlayers, int noOfCardsPerPlayer) {
        
        //generate game id
        this.gameId = new Date().getTime();
        this.totalCardsInDeck = totalCardsInDeck;
        this.numberOfPlayers = numberOfPlayers;
        this.noOfCardsPerPlayer = noOfCardsPerPlayer;
        
        newDeck = new Deck(this.totalCardsInDeck);
        
        //initialise player list and their cards on hand
        
        this.players = new ArrayList<Player>();
        
        
        for (int i=0;i<this.numberOfPlayers;i++)
        {
            String playerId = playerIdList.get(i);
            String playerName = playerNameList.get(i);

            Player newPlayer = new Player(playerId, playerName);
            
            this.players.add(newPlayer);

            //removeTopCard from game deck

            for (int j=0; j<this.noOfCardsPerPlayer; j++)
            {
                newPlayer.addCard(newDeck.drawTopCard());
            }
            System.out.println("No of Players " +players.size());
        }  
        
            
        
        //output game info
        
        System.out.println("Game ID:" +this.gameId);
        
        //draw one card from game deck and puts in discard pile
        discardPile = new ArrayList<Card>();
        discardPile.add(newDeck.drawTopCard());
        System.out.println("Discard Card: " + discardPile.get(0).getCardInfo());
        System.out.println("Cards on deck: " + newDeck.getStackOfCards().size());
        
        for (int i=0;i<this.numberOfPlayers;i++)
        {
            
            System.out.println("\tPlayer: id=" + players.get(i).getPlayerId() + ", name=" + players.get(i).getPlayerName());
            System.out.println("\tCards in hand:" + players.get(i).getCardsOnHand().size());
            
            
            for(int j=0; j<players.get(i).getCardsOnHand().size();j++)
            {
                System.out.println("\tCard:" + players.get(i).getCardsOnHand().get(j).getCardInfo());
                
            }
            
            System.out.println("\tPlayer's Current Score:" + players.get(i).calculatePlayerScore() +"\n");
        }
        
    
    }
}
