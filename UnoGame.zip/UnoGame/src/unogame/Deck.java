package unogame;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class Deck implements Serializable  {
    private ArrayList<Card> stackOfCards;
    private ArrayList<Card> shuffledCards;
    
    public Deck(int noOfCardsInDeck)
    {
        //initialise for new game
        this.stackOfCards = prepareNewDeck(noOfCardsInDeck);
        
    }
    
    public ArrayList<Card> getStackOfCards()
    {
        return this.stackOfCards;
    }

    private ArrayList<Card> prepareNewDeck(int noOfCardsInDeck)
    {
        Card card;
        ArrayList<Card> tempStack = new ArrayList<Card>();
        ArrayList<Card> preparedStack = new ArrayList<Card>();
        
        //Initialise deck standard 108 cards in Uno Game
        //25 cards per color, 4 Wild cards and 4 WildDrawFour cards
        
        //Red Cards
        card = new Card ("Red","Normal",0,"");
        tempStack.add(card);
        card = new Card ("Red","Normal",1,"");
        tempStack.add(card);
        card = new Card ("Red","Normal",1,"");
        tempStack.add(card);
        card = new Card ("Red","Normal",2,"");
        tempStack.add(card);
        card = new Card ("Red","Normal",2,"");
        tempStack.add(card);
        card = new Card ("Red","Normal",3,"");
        tempStack.add(card);
        card = new Card ("Red","Normal",3,"");
        tempStack.add(card);
        card = new Card ("Red","Normal",4,"");
        tempStack.add(card);
        card = new Card ("Red","Normal",4,"");
        tempStack.add(card);
        card = new Card ("Red","Normal",5,"");
        tempStack.add(card);
        card = new Card ("Red","Normal",5,"");
        tempStack.add(card);
        card = new Card ("Red","Normal",6,"");
        tempStack.add(card);
        card = new Card ("Red","Normal",6,"");
        tempStack.add(card);
        card = new Card ("Red","Normal",7,"");
        tempStack.add(card);
        card = new Card ("Red","Normal",7,"");
        tempStack.add(card);
        card = new Card ("Red","Normal",8,"");
        tempStack.add(card);
        card = new Card ("Red","Normal",8,"");
        tempStack.add(card);
        card = new Card ("Red","Normal",9,"");
        tempStack.add(card);
        card = new Card ("Red","Normal",9,"");
        tempStack.add(card);
        card = new Card ("Red","Skip",20,"");
        tempStack.add(card);
        card = new Card ("Red","Skip",20,"");
        tempStack.add(card);
        card = new Card ("Red","Reverse",20,"");
        tempStack.add(card);
        card = new Card ("Red","Reverse",20,"");
        tempStack.add(card);
        card = new Card ("Red","DrawTwo",20,"");
        tempStack.add(card);
        card = new Card ("Red","DrawTwo",20,"");
        tempStack.add(card);
       
        //Yellow Cards
        card = new Card ("Yellow","Normal",0,"");
        tempStack.add(card);
        card = new Card ("Yellow","Normal",1,"");
        tempStack.add(card);
        card = new Card ("Yellow","Normal",1,"");
        tempStack.add(card);
        card = new Card ("Yellow","Normal",2,"");
        tempStack.add(card);
        card = new Card ("Yellow","Normal",2,"");
        tempStack.add(card);
        card = new Card ("Yellow","Normal",3,"");
        tempStack.add(card);
        card = new Card ("Yellow","Normal",3,"");
        tempStack.add(card);
        card = new Card ("Yellow","Normal",4,"");
        tempStack.add(card);
        card = new Card ("Yellow","Normal",4,"");
        tempStack.add(card);
        card = new Card ("Yellow","Normal",5,"");
        tempStack.add(card);
        card = new Card ("Yellow","Normal",5,"");
        tempStack.add(card);
        card = new Card ("Yellow","Normal",6,"");
        tempStack.add(card);
        card = new Card ("Yellow","Normal",6,"");
        tempStack.add(card);
        card = new Card ("Yellow","Normal",7,"");
        tempStack.add(card);
        card = new Card ("Yellow","Normal",7,"");
        tempStack.add(card);
        card = new Card ("Yellow","Normal",8,"");
        tempStack.add(card);
        card = new Card ("Yellow","Normal",8,"");
        tempStack.add(card);
        card = new Card ("Yellow","Normal",9,"");
        tempStack.add(card);
        card = new Card ("Yellow","Normal",9,"");
        tempStack.add(card);
        card = new Card ("Yellow","Skip",20,"");
        tempStack.add(card);
        card = new Card ("Yellow","Skip",20,"");
        tempStack.add(card);
        card = new Card ("Yellow","Reverse",20,"");
        tempStack.add(card);
        card = new Card ("Yellow","Reverse",20,"");
        tempStack.add(card);
        card = new Card ("Yellow","DrawTwo",20,"");
        tempStack.add(card);
        card = new Card ("Yellow","DrawTwo",20,"");
        tempStack.add(card);
        
        //Blue Cards
        card = new Card ("Blue","Normal",0,"");
        tempStack.add(card);
        card = new Card ("Blue","Normal",1,"");
        tempStack.add(card);
        card = new Card ("Blue","Normal",1,"");
        tempStack.add(card);
        card = new Card ("Blue","Normal",2,"");
        tempStack.add(card);
        card = new Card ("Blue","Normal",2,"");
        tempStack.add(card);
        card = new Card ("Blue","Normal",3,"");
        tempStack.add(card);
        card = new Card ("Blue","Normal",3,"");
        tempStack.add(card);
        card = new Card ("Blue","Normal",4,"");
        tempStack.add(card);
        card = new Card ("Blue","Normal",4,"");
        tempStack.add(card);
        card = new Card ("Blue","Normal",5,"");
        tempStack.add(card);
        card = new Card ("Blue","Normal",5,"");
        tempStack.add(card);
        card = new Card ("Blue","Normal",6,"");
        tempStack.add(card);
        card = new Card ("Blue","Normal",6,"");
        tempStack.add(card);
        card = new Card ("Blue","Normal",7,"");
        tempStack.add(card);
        card = new Card ("Blue","Normal",7,"");
        tempStack.add(card);
        card = new Card ("Blue","Normal",8,"");
        tempStack.add(card);
        card = new Card ("Blue","Normal",8,"");
        tempStack.add(card);
        card = new Card ("Blue","Normal",9,"");
        tempStack.add(card);
        card = new Card ("Blue","Normal",9,"");
        tempStack.add(card);
        card = new Card ("Blue","Skip",20,"");
        tempStack.add(card);
        card = new Card ("Blue","Skip",20,"");
        tempStack.add(card);
        card = new Card ("Blue","Reverse",20,"");
        tempStack.add(card);
        card = new Card ("Blue","Reverse",20,"");
        tempStack.add(card);
        card = new Card ("Blue","DrawTwo",20,"");
        tempStack.add(card);
        card = new Card ("Blue","DrawTwo",20,"");
        tempStack.add(card);
        
        //Green Cards
        card = new Card ("Green","Normal",0,"");
        tempStack.add(card);
        card = new Card ("Green","Normal",1,"");
        tempStack.add(card);
        card = new Card ("Green","Normal",1,"");
        tempStack.add(card);
        card = new Card ("Green","Normal",2,"");
        tempStack.add(card);
        card = new Card ("Green","Normal",2,"");
        tempStack.add(card);
        card = new Card ("Green","Normal",3,"");
        tempStack.add(card);
        card = new Card ("Green","Normal",3,"");
        tempStack.add(card);
        card = new Card ("Green","Normal",4,"");
        tempStack.add(card);
        card = new Card ("Green","Normal",4,"");
        tempStack.add(card);
        card = new Card ("Green","Normal",5,"");
        tempStack.add(card);
        card = new Card ("Green","Normal",5,"");
        tempStack.add(card);
        card = new Card ("Green","Normal",6,"");
        tempStack.add(card);
        card = new Card ("Green","Normal",6,"");
        tempStack.add(card);
        card = new Card ("Green","Normal",7,"");
        tempStack.add(card);
        card = new Card ("Green","Normal",7,"");
        tempStack.add(card);
        card = new Card ("Green","Normal",8,"");
        tempStack.add(card);
        card = new Card ("Green","Normal",8,"");
        tempStack.add(card);
        card = new Card ("Green","Normal",9,"");
        tempStack.add(card);
        card = new Card ("Green","Normal",9,"");
        tempStack.add(card);
        card = new Card ("Green","Skip",20,"");
        tempStack.add(card);
        card = new Card ("Green","Skip",20,"");
        tempStack.add(card);
        card = new Card ("Green","Reverse",20,"");
        tempStack.add(card);
        card = new Card ("Green","Reverse",20,"");
        tempStack.add(card);
        card = new Card ("Green","DrawTwo",20,"");
        tempStack.add(card);
        card = new Card ("Green","DrawTwo",20,"");
        tempStack.add(card);
        
        //Four Wild Cards
        card = new Card ("Red","Wild",50,"");
        tempStack.add(card);
        card = new Card ("Yellow","Wild",50,"");
        tempStack.add(card);
        card = new Card ("Blue","Wild",50,"");
        tempStack.add(card);
        card = new Card ("Green","Wild",50,"");
        tempStack.add(card);
        
        //Four WildDrawFour Cards
        card = new Card ("Red","WildDrawFour",50,"");
        tempStack.add(card);
        card = new Card ("Yellow","WildDrawFour",50,"");
        tempStack.add(card);
        card = new Card ("Blue","WildDrawFour",50,"");
        tempStack.add(card);
        card = new Card ("Green","WildDrawFour",50,"");
        tempStack.add(card);
        
        System.out.println("Deck Initiliased.");
        System.out.println("\n\nGame Deck:\n");
        
        //put cards into preparedStack
        for (int i=0; i<noOfCardsInDeck; i++)
        {
            Random randomGenerator = new Random();
            int preparedCardPos = randomGenerator.nextInt(108-i-1);
            Card pickedCard = tempStack.get(preparedCardPos);
            System.out.println(pickedCard.getCardInfo());
            preparedStack.add(pickedCard);
            tempStack.remove(preparedCardPos);
            
            
        }    
        
        return preparedStack;
    }       
 
    
    public Card drawTopCard()
    {
        //return the top card
        Card drawnCard = stackOfCards.get(0);
        
        //remove top card from game deck
        stackOfCards.remove(0);
        
        return drawnCard;
    }
    
     
}    
