package unogame;

import java.util.ArrayList;


public class Player {

    private String playerId;  
    private String playerName;    
    private ArrayList<Card> cardsOnHand;
    private int score;   

    public Player(String playerId, String playerName) {
        this.playerId = playerId;
        this.playerName = playerName;
        this.cardsOnHand = new ArrayList<Card>();
        this.score = 0;
    }

    public String getPlayerId() 
    {
        return playerId;
    }
    
    public void setPlayerId(String playerId) 
    {
        this.playerId = playerId;
    }
    
    public String getPlayerName() 
    {
        return playerName;
    }
    
    public void setPlayerName(String playerName) 
    {
        this.playerName = playerName;
    }

    public ArrayList<Card> getCardsOnHand() 
    {
        return cardsOnHand;
    }
    
    public void addCard(Card card) 
    {
        cardsOnHand.add(card);
    }
    
    public void removeCardsOnHand(int cardPos)
    {
        cardsOnHand.remove(cardPos);
    }
    
    public int calculatePlayerScore ()
    {   
        int playerScore = 0;
        
        for(int i=0; i<cardsOnHand.size();i++)
        {
            Card currentCard = cardsOnHand.get(i);
            playerScore = playerScore + currentCard.getValue();
            
        }
        
        return playerScore;
    }
}

