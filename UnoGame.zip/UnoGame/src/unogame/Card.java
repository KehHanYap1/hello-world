package unogame;

public class Card {

/*
Colour = Red, Yellow, Green, Blue
actionCard - Skip, Reverse, DrawTwo, Wild, WildDrawFour

Number card = 0=0pt, 1=1pt ... 9=9pt
DrawTwo, Reverse, Skip = 20pt
Wild, WildDrawFour = 50pt
*/
    private int CardId; 
    private String colour;
    private String type; //Normal, Reverse, Skip, DrawTwo, Wild, WildDrawFour
    private String imageName; //image name is in the format of {Color}{Type}{Value}
    private int value;

    public Card(String colour, String type, int value, String imageName) {
        this.colour = colour;
        this.type = type;
        this.value = value;
        this.imageName = this.colour + this.type + this.value;
    }
  
    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }
    
    public String getCardInfo() {
        return "colour=" + this.colour + ", type=" + this.type + ", value=" + this.value + ", image=" + this.imageName;
    }

    
}
